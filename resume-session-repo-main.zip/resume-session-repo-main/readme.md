# Career Resources & Resume Building Guide

This repository contains a curated list of resources, training programs, and templates to help you excel in your professional journey. Whether you are a student or a corporate professional, these tools and tips will assist you in landing your next big opportunity.

---

## 📑 Table of Contents
- [🛠 Tools & Extensions](#-tools--extensions)
- [🎓 Training & Certifications](#-training--certifications)
  - [Google Cloud](#google-cloud)
  - [AWS & Databricks](#aws--databricks)
- [📧 Networking & Cold Mailing](#-networking--cold-mailing)
  - [Cold Outreach Template](#cold-outreach-template)
  - [LinkedIn Connection Requests](#linkedin-connection-requests)
- [📄 Resume Building Tips](#-resume-building-tips)
  - [Reference Resume (Data & AI)](#reference-resume-data--ai)
- [🔗 LinkedIn Optimization](#-linkedin-optimization)
  - [Shorten Your Profile URL](#shorten-your-profile-url)
  - [LinkedIn URL Hacking (Advanced Search)](#linkedin-url-hacking-advanced-search)
- [📈 Naukri Profile Optimization](#-naukri-profile-optimization)

---

## 🛠 Tools & Extensions

### Jobalytics - Job Keyword Analyzer
Use this tool to analyze job descriptions and optimize your resume with the right keywords.
*   **Link:** [Jobalytics Chrome Extension](https://chromewebstore.google.com/detail/jobalytics-resume-keyword/fkiljfkkceaopbpfgfmjdnkiejaifkgd?hl=en&pli=1)

---

## 🎓 Training & Certifications

### Google Cloud Training
> [!TIP]
> Google offers various paths for both students and experienced professionals.

#### For Students
*   **Google Cloud Arcade:** Participate in games and earn badges while learning.
    *   [Cloud Skills Boost Arcade](https://go.cloudskillsboost.google/arcade)

#### For Corporate Employees
*   **Free Certification:** Check your eligibility for free certification vouchers.
    *   [Apply Here](https://cloud.google.com/resources/pck-page?hl=en)
*   **Learning Paths:**
    *   [Partner Skills Portal](http://partner.skills.google)
    *   [Data Engineer Path](https://partner.skills.google/paths/85)
    *   [Machine Learning Engineer Path](https://partner.skills.google/paths/84)

### AWS & Databricks

#### AWS Training
*   **AWS Builder Labs:** [Explore AWS Learning](https://aws.amazon.com/builder/)

#### LatEx for Resumes
*   **Overleaf:** The best tool for professional LaTeX resume templates.
    *   [Overleaf Projects](https://www.overleaf.com/project)

#### Databricks Partner Academy
Access various professional paths on Databricks: [Partner Academy](https://partner-academy.databricks.com/learn)

| Category | Course Name | Enrollment Link |
| :--- | :--- | :--- |
| **Professional Data Engineering** | Databricks Streaming & Lakeflow | [Link](https://partner-academy.databricks.com/learn/courses/3855/databricks-streaming-and-lakeflow-spark-declarative-pipelines) |
| | Databricks Data Privacy | [Link](https://partner-academy.databricks.com/learn/courses/3856/databricks-data-privacy) |
| | Performance Optimization | [Link](https://partner-academy.databricks.com/learn/courses/3857/databricks-performance-optimization) |
| | Deployment with Asset Bundles | [Link](https://partner-academy.databricks.com/learn/courses/3858/automated-deployment-with-declarative-automation-bundles) |
| **Data Analysis** | AI/BI for Data Analysts | [Link](https://partner-academy.databricks.com/learn/courses/3850/aibi-for-data-analysts) |
| | SQL Analytics on Databricks | [Link](https://partner-academy.databricks.com/learn/courses/3897/sql-analytics-on-databricks) |
| **Associate ML Practitioner** | Data Prep for ML | [Link](https://partner-academy.databricks.com/learn/courses/3865/data-preparation-for-machine-learning) |
| | Model Development | [Link](https://partner-academy.databricks.com/learn/courses/3866/machine-learning-model-development) |
| | Model Deployment | [Link](https://partner-academy.databricks.com/learn/courses/3867/machine-learning-model-deployment) |
| | Machine Learning Operations | [Link](https://partner-academy.databricks.com/learn/courses/3868/machine-learning-operations) |
| **Professional ML Practitioner**| Advanced ML Operations | [Link](https://partner-academy.databricks.com/learn/courses/3869/advanced-machine-learning-operations) |
| | Machine Learning at Scale | [Link](https://partner-academy.databricks.com/learn/courses/3870/machine-learning-at-scale) |
| **Generative AI Engineering** | Building Retrieval Agents | [Link](https://partner-academy.databricks.com/learn/courses/3861/building-retrieval-agents-on-databricks) |
| | Building Single Agent Apps | [Link](https://partner-academy.databricks.com/learn/courses/3862/building-single-agent-applications-on-databricks) |
| | Agent Evaluation | [Link](https://partner-academy.databricks.com/learn/courses/3863/agent-evaluation-on-databricks) |
| | Deployment & Monitoring | [Link](https://partner-academy.databricks.com/learn/courses/3864/generative-ai-application-deployment-and-monitoring) |

---

## 📧 Networking & Cold Mailing

### Cold Outreach Template
Use this template to reach out to hiring managers via LinkedIn or Email.

```text
Dear [Hiring Manager's Name],

My name is [Your Name], and I was referred to you by [Referral's Name], [Referral's Role] at [Company Name]. They suggested I reach out regarding the [Job Title] position (Job ID: [XXXXX]).

I bring [X years] of experience in [Domain], with a strong track record in [Skill/Area]. At [Previous Company], I [specific achievement relevant to the role].

I admire [Company Name]'s work in [specific area/product], and I am confident I can add immediate value to your team.

I've attached my resume and would welcome a conversation at your earliest convenience. Please feel free to reach me at [Phone] or via email.

Looking forward to hearing from you.

Best regards,
[Your Full Name]
[LinkedIn URL] | [Phone Number]
```

### LinkedIn Connection Requests
When sending a connection request, always include a personalized note to increase your acceptance rate.

#### Template 1: To a Recruiter/Hiring Manager
> Hi [Name], I’m a [Your Role/Student] interested in the [Job Title] role at [Company]. I’d love to connect and learn more about the team's work. Best, [Your Name].

#### Template 2: To an Alumni or Shared Interest
> Hi [Name], I’m a student at [University] and saw your profile. I’m very interested in your career path in [Field] and would love to connect. Thanks!

#### Template 3: After a Software/Event referral
> Hi [Name], [Referral Name] suggested I reach out to you regarding [Topic/Job]. I’d love to connect and briefly chat about your experience at [Company]. Best regards!

---

## 📄 Resume Building Tips

### The Golden Formula
> **Action Verb + What You Did + By How Much + Business Impact**

- **Length:** If you have **less than 5 years** of experience, keep your resume to exactly **1 page**.
- **Open Source:** Highlight contributions to Apache, GSoC, or Google projects.
- **Project Impact:** Add GitHub repositories that demonstrate real-world impact.
- **Format:** Save your resume as a `.pdf` unless `.docx` is explicitly requested.
- **Keep it Clean:**
    - Avoid tables, headers, footers, and text boxes (ATS-friendly).
    - Remove hobbies and graduation years to save space and avoid bias.
- **Reference Resume:** [Download/View Data & AI Engineer Resume (PDF)](./resume_Data&AI_engineer.pdf)


---

## 🔗 LinkedIn Optimization

### Shorten Your Profile URL
A short, clean URL looks much more professional on a resume.

#### Mobile Steps:
1. Tap your profile picture -> **View Profile**.
2. Tap the **three dots** (More) in your intro section.
3. Tap **Edit** (pencil icon) near the Contact Info.
4. Tap on your current **Profile URL** to open the editing page.
5. Click the pencil icon next to your custom URL, edit it to something short (e.g., `linkedin.com/in/yourname`), and save.

### 🚀 LinkedIn URL Hacking (Advanced Search)
Stay ahead of the competition by filtering jobs by the exact timing they were posted.

#### 🛠️ How to use this:
1. **Search:** Perform your job search on LinkedIn as usual.
2. **Filter:** Set the "Date Posted" filter to **Past 24 hours**. This ensures the `f_TPR` parameter appears in your URL.
3. **Hack:** In your browser's address bar, find `f_TPR=r86400` and change the number `86400` to your desired timeframe in seconds.

#### 📝 Example:
*   **Original URL (Past 24 Hours):**
    `.../search/?f_TPR=r86400&keywords=Director%20of%20Operations`
*   **Hacked URL (Past 1 Hour):**
    `.../search/?f_TPR=r3600&keywords=Director%20of%20Operations`

#### Recency Filter (`f_TPR`)
Modify the `f_TPR` parameter in the LinkedIn search URL to find jobs within precise timeframes:

| Value | Timeframe |
| :--- | :--- |
| `r3600` | Last 1 Hour |
| `r21600` | Last 6 Hours |
| `r86400` | Last 24 Hours |
| `r604800` | Last Week |
| `r2592000` | Last Month |

> [!TIP]
> The number after `r` represents **seconds**. For example, 1 hour = 3600 seconds.

#### Common URL Parameters
- **`keywords`**: Search terms (e.g., `keywords=Director%20of%20Operations`). Use `%20` for spaces.
- **`location`**: Target location (e.g., `location=Florida`).
- **`geoId`**: The specific geographic ID for a location (e.g., `103644278`).
- **`distance`**: Search radius in miles (e.g., `distance=50`).
- **`sortBy=DD`**: Sort results by **Date Posted** (Most recent first).
- **`sortBy=R`**: Sort results by **Relevance** (LinkedIn's default).
- **`currentJobId`**: Specifies the job currently being viewed (can be ignored for search results).
- **`origin`**: Indicates the search is being filtered from the job search page (can be ignored).

---

## 📈 Naukri Profile Optimization
A well-optimized Naukri profile is key to attracting recruiters in the Indian job market. Below is a complete walkthrough of an optimized profile setup (100% completion score).

<details>
<summary><b>1. Profile Overview (100% Score)</b></summary>

![Profile Overview](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.06%20PM.png)
</details>

<details>
<summary><b>2. Resume Headline & Key Skills</b></summary>

![Headline & Skills](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.31%20PM.png)
</details>

<details>
<summary><b>3. Employment & Education</b></summary>

![Employment 1](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.39%20PM.png)
![Employment 2](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.46%20PM.png)
</details>

<details>
<summary><b>4. Projects & IT Skills</b></summary>

![Projects](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.52%20PM.png)
![IT Skills](./naukri%20photos/Screenshot%202026-04-11%20at%204.05.59%20PM.png)
</details>

<details>
<summary><b>5. Profile Summary & Accomplishments</b></summary>

![Summary](./naukri%20photos/Screenshot%202026-04-11%20at%204.06.10%20PM.png)
![Publications](./naukri%20photos/Screenshot%202026-04-11%20at%204.06.16%20PM.png)
</details>

<details>
<summary><b>6. Career Profile & Personal Details</b></summary>

![Career Profile](./naukri%20photos/Screenshot%202026-04-11%20at%204.06.24%20PM.png)
![Personal Details 1](./naukri%20photos/Screenshot%202026-04-11%20at%204.06.33%20PM.png)
![Personal Details 2](./naukri%20photos/Screenshot%202026-04-11%20at%204.06.39%20PM.png)
</details>

---

